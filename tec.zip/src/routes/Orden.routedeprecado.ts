/* import { Router } from 'express';
import OrdenController from '@controllers/Orden.controllerdeprecado';
const router = Router();
const controller = new OrdenController();

router.post('/crear', controller.insertar);
router.put('/actualizar/:idorden', controller.actualizar);
router.delete('/eliminar/:idorden', controller.eliminar);
router.get('/obtener', controller.obtener);

export default router;
 */